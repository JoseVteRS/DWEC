// Ejercicio 1.3 - Función autoinvocada que recibe dos parámetros

(function(texto, numero) {
  var resultado = texto + numero;
  console.log("Ejercicio 1.3 - Concatenación:");
  console.log(resultado);
})("El número es: ", 42);

