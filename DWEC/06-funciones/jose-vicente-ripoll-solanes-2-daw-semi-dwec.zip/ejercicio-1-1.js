// Ejercicio 1.1 - Función tradicional que retorna el cuadrado de un número

function cuadrado(numero) {
  return numero * numero;
}

// Usar la función para mostrar el cuadrado de 5
console.log("Ejercicio 1.1 - Cuadrado de 5:");
console.log(cuadrado(5)); // Resultado: 25

